<?php
namespace App\Models;

use PDO;

class User extends \Core\Model
{
	public $errors = [];

	public function __construct($data)
	{
		foreach ($data as $key => $value)
		{
			$this->$key	= $value;
		};
	}

	public function save()
	{
		$this->validate();

		if (empty($this->errors))
		{
			$password_hash = password_hash($this->password, PASSWORD_DEFAULT);

			$sql = "INSERT INTO users (name, mail, password_hash)
				VALUES (:name, :mail, :password_hash)";

			$db = \Core\Model::getDb();
			$stmt = $db->prepare($sql);

			$stmt->bindValue(':name', $this->name, PDO::PARAM_STR);
			$stmt->bindValue(':mail', $this->mail, PDO::PARAM_STR);
			$stmt->bindValue(':password_hash', $password_hash, PDO::PARAM_STR);

			$stmt->execute();
			return true;
		}
		return false;
	}

	public function validate()
	{
		if ($this->name == '')
			$this->errors[] = "Name is required";
		
		if (filter_var($this->mail, FILTER_VALIDATE_EMAIL) === false)
			$this->errors[] = "Invalide e-mail";

		if ($this->password != $this->password_re)
			$this->errors[] = "Password must match confirmation";
		
		if (strlen($this->password) < 8)
			$this->errors[] = "Please enter at least 8 characters for the password";

		if (preg_match('/.*[a-z]+.*/', $this->password) == 0)
			$this->errors[] = "Password need at least one lowercase letter";
		
		if (preg_match('/.*[A-Z]+.*/', $this->password) == 0)
			$this->errors[] = "Password need at least one uppercase letter";

		if (preg_match('/.*[0-9]+.*/', $this->password) == 0)
			$this->errors[] = "Password need at least one digit";
	}
}
?>
