<?php
namespace App\Models;

use PDO;
use Core\Token;

class User extends \Core\Model
{
	public $errors = [];

	public function __construct($data = [])
	{
		foreach ($data as $key => $value)
		{
			$this->$key	= $value;
		};
	}

	public function save()
	{
		$this->validate();

		if (empty($this->errors))
		{
			$password_hash = password_hash($this->password, PASSWORD_DEFAULT);

			$token = new Token();
			$hashed_token = $token->getHash();
			$this->activation_token = $token->getValue();

			$sql = "INSERT INTO users (name, mail, password_hash, activation_hash)
				VALUES (:name, :mail, :password_hash, :activation_hash)";

			$db = \Core\Model::getDb();
			$stmt = $db->prepare($sql);

			$stmt->bindValue(':name', $this->name, PDO::PARAM_STR);
			$stmt->bindValue(':mail', $this->mail, PDO::PARAM_STR);
			$stmt->bindValue(':password_hash', $password_hash, PDO::PARAM_STR);
			$stmt->bindValue(':activation_hash', $hashed_token, PDO::PARAM_STR);

			$stmt->execute();
			return true;
		}
		return false;
	}

	public function validate()
	{
		if ($this->name == '')
			$this->errors[] = "Name is required";

		if (filter_var($this->mail, FILTER_VALIDATE_EMAIL) === false)
			$this->errors[] = "Invalide e-mail";
		
		if (static::emailExists($this->mail))
			$this->errors[] = "E-mail is already in use";
		
		$this->validatePassword();
	}

	protected function validatePassword()
	{
		if ($this->password != $this->password_re)
			$this->errors[] = "Password must match confirmation";

		if (strlen($this->password) < 8)
			$this->errors[] = "Please enter at least 8 characters for the password";

		if (preg_match('/.*[a-z]+.*/', $this->password) == 0)
			$this->errors[] = "Password need at least one lowercase letter";

		if (preg_match('/.*[A-Z]+.*/', $this->password) == 0)
			$this->errors[] = "Password need at least one uppercase letter";

		if (preg_match('/.*[0-9]+.*/', $this->password) == 0)
			$this->errors[] = "Password need at least one digit";
	}

	public static function emailExists($mail)
	{
		return static::findByEmail($mail) !== false;
	}

	public function savePassword()
	{
		$this->validatePassword();

		if (empty($this->errors))
		{
			$password_hash = password_hash($this->password, PASSWORD_DEFAULT);
			
			$sql = "UPDATE users
				SET password_reset_hash = :null,
				password_reset_expires_at = :null,
				password_hash = :password_hash
				WHERE id = :id";

			$db = static::getDb();
			$stmt = $db->prepare($sql);

			$stmt->bindValue(':password_hash', $password_hash, PDO::PARAM_STR);
			$stmt->bindValue(':null', NULL, PDO::PARAM_INT);
			$stmt->bindValue(':id', $this->id, PDO::PARAM_INT);

			$stmt->execute();

			return true;
		}
		return false;
	}

	public static function findByEmail($mail)
	{
		$sql = 'SELECT * FROM users WHERE mail = :mail';

		$db = static::getDb();
		$stmt = $db->prepare($sql);
		$stmt->bindParam(':mail', $mail, PDO::PARAM_STR);
		$stmt->setFetchMode(PDO::FETCH_CLASS, get_called_class());

		$stmt->execute();
		return $stmt->fetch();
	}

	public static function findById($id)
	{
		$sql = 'SELECT * FROM users WHERE id = :id';

		$db = static::getDb();
		$stmt = $db->prepare($sql);
		$stmt->bindParam(':id', $id, PDO::PARAM_STR);
		$stmt->setFetchMode(PDO::FETCH_CLASS, get_called_class());

		$stmt->execute();
		return $stmt->fetch();
	}
	
	public static function findByPasswordReset($token)
	{
		$token = new Token($token);
		$password_reset_hash = $token->getHash();
		
		$sql = 'SELECT * FROM users WHERE password_reset_hash = :password_reset_hash';

		$db = static::getDb();
		$stmt = $db->prepare($sql);
		$stmt->bindParam(':password_reset_hash', $password_reset_hash, PDO::PARAM_STR);
		$stmt->setFetchMode(PDO::FETCH_CLASS, get_called_class());

		$stmt->execute();
		$user = $stmt->fetch();
		
		if ($user)
		{
			if (strtotime($user->password_reset_expires_at) > time())
				return $user;
		}
		return false;
	}

	public static function findByActivationHash($token)
	{
		$token = new Token($token);
		$activation_hash = $token->getHash();
		
		$sql = 'SELECT * FROM users WHERE activation_hash = :activation_hash';

		$db = static::getDb();
		$stmt = $db->prepare($sql);
		$stmt->bindParam(':activation_hash', $activation_hash, PDO::PARAM_STR);
		$stmt->setFetchMode(PDO::FETCH_CLASS, get_called_class());

		$stmt->execute();
		return $stmt->fetch();
	}

	public static function authenticate($mail, $password)
	{
		$user = static::findByEmail($_POST['mail']);

		if ($user)
		{
			if (password_verify($password, $user->password_hash))
			{
				return $user;
			}
		}
		return (false);
	}

	public static function sendPasswordReset($mail)
	{
		$user = static::findByEmail($mail);
		if ($user)
		{
			$user->startPasswordReset();
			$user->sendPasswordResetEmail();
		}
	}

	protected function startPasswordReset()
	{
		$token = new Token();
		$hashed_token = $token->getHash();
		$this->password_reset_token = $token->getValue();

		$expiry_timestamp = time() + 2 * 60 * 60;

		$sql = "UPDATE users
			SET password_reset_hash = :hashed_token,
			password_reset_expires_at = :expiry_timestamp
			WHERE id = :id";

		$db = static::getDb();
		$stmt = $db->prepare($sql);

		$stmt->bindValue(':hashed_token', $hashed_token, PDO::PARAM_STR);
		$stmt->bindValue(':expiry_timestamp', date('Y-m-d H:i:s', $expiry_timestamp), PDO::PARAM_STR);
		$stmt->bindValue(':id', $this->id, PDO::PARAM_INT);

		return $stmt->execute();
	}

	protected function sendPasswordResetEmail()
	{
		$url = "http://".$_SERVER['HTTP_HOST']."/password/reset/".$this->password_reset_token;
		$text = "Please click the following url to reset your password: ".$url;
		$html = "Please click <a href='".$url."'>here</a> to reset your password";
		$html_layout = "<html><head><head><body>".$html."</body></head></html>";
		$headers = 'Content-type: text/html; charset=iso-8859-1' . "\r\n" .
			'X-Mailer: PHP/' . phpversion();


		mail($this->mail, "Password Reset", $html_layout, $headers);
	}
	
	public function sendActivationEmail()
	{
		$url = "http://".$_SERVER['HTTP_HOST']."/signup/activate/".$this->activation_token;
		$html = "Please click <a href='".$url."'>here</a> to activate your account";
		$html_layout = "<html><head><head><body>".$html."</body></head></html>";
		$headers = 'Content-type: text/html; charset=iso-8859-1' . "\r\n" .
			'X-Mailer: PHP/' . phpversion();

		mail($this->mail, "Account Activation - Camagru", $html_layout, $headers);
	}

	public function activateAccount()
	{
		$sql = "UPDATE users
			SET is_active = 1
			WHERE id = :id";

		$db = static::getDb();
		$stmt = $db->prepare($sql);

		$stmt->bindValue(':id', $this->id, PDO::PARAM_INT);

		return $stmt->execute();
	}
}
?>
