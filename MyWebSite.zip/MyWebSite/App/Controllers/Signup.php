<?php
namespace App\Controllers;

use Core\View;
use \App\Models\User;

class Signup extends \Core\Controller
{
	public function newAction()
	{
		View::render('Auth/index.php');
	}

	public function createAction()
	{
		$user = new User($_POST);

		if ($user->save() === true)
		{
			$user->sendActivationEmail();
			$_SESSION['message'] = "Sign-up successful, check your mail to activate your account";
			View::render('Auth/Login.php');
		} else {
			View::render('Auth/index.php', [
				'errors' => $user->errors
			]);
		}
	}

	public function activateAction()
	{
		$token = $this->route_params['token'];

		$user = User::findByActivationHash($token);
		if ($user)
		{
			//var_dump($user);
			$user->activateAccount();
			$_SESSION['message'] = "Your account is activated you can now login";
			View::render('Auth/Login.php');
		} else {
			$_SESSION['message'] = "Invalide account activation token";
			View::render('Auth/Login.php');
		}
	}
}
?>
