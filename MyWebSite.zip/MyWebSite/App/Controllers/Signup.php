<?php
namespace App\Controllers;

use Core\View;
use \App\Models\User;

class Signup extends \Core\Controller
{
	public function newAction()
	{
		View::render('Auth/index.php');
	}

	public function createAction()
	{
		$user = new User($_POST);
		echo "Saving... ";
		if ($user->save() === true)
		{
			echo "Success !";
		} else {
			View::render('Auth/index.php', [
				'errors' => $user->errors
			]);
		}
	}
}
?>
