<?php

namespace App\Controllers;

use Core\View;
use Core\Auth;

class Home extends \Core\Controller
{
	public function indexAction()
	{
		View::render('Home/index.php',[
		'user' => Auth::getUser() 
		]);
	}
}
?>
