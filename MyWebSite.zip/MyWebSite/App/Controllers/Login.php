<?php
namespace App\Controllers;

use Core\View;
use \App\Models\User;
use Core\Auth;

class Login extends \Core\Controller
{
	public function newAction()
	{
		View::render('Auth/Login.php');
	}

	public function createAction()
	{
		$user = User::authenticate($_POST['mail'], $_POST['password']);

		if ($user && $user->is_active)
		{
			Auth::login($user);
			$this->redirect(Auth::getReturnToPage());
		}
		else
		{
			if (!$user->is_active && isset($user))
			{	
				$user->errors[] = "Account not activated please check your mail inbox";
			} else {
				$user->errors[] = "Error password or mail is invalid";
			}
			View::render('Auth/Login.php', [
				"errors" => $user->errors,
				"mail" => $_POST['mail']
			]);
		}
	}

	public function destroyAction()
	{
		Auth::logout();

		$this->redirect("/");
	}
}
?>
