<?php

namespace App\Controllers\Admin;

use \Core\Model;
use \Core\View;

class Setup extends \Core\Controller
{
	public function indexAction()
	{
		View::render('Admin/setup.php', [
			'main' => 'Admin/setup.php',
		]);
	}

	public function startAction()
	{
		require ("./config/database.php");

		if ($_POST['user'] == $DB_USER && $_POST['password'] == $DB_PASSWORD)
			Model::setupDb();
		echo file_get_contents("http://localhost:8080/");
	}
}
?>
