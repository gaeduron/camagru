<?php

namespace App\Controllers\Admin;

class Users extends \Core\Controller
{
	public function indexAction()
	{
		echo "Welcome to Admin/Users class where action is index";
	}
}
?>
