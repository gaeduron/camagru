<?php

namespace App\Controllers;

use \Core\Model;
use \Core\View;
use \App\Models\User;

class Password extends \Core\Controller
{
	public function forgotAction()
	{
		View::render('Password/forgot.php');
	}
	
	public function RequestResetAction()
	{
		User::sendPasswordReset($_POST['mail']);
		View::render('Password/reset-requested.php');
	}

	public function resetAction()
	{
		$token = $this->route_params['token'];

		$user = User::findByPasswordReset($token);
		if ($user)
		{
			View::render('Password/reset.php', [
				'token' => $token
			]);
		} else {
			View::render('Password/token_expired.php');
		}
	}

	public function changeAction()
	{
		$user = User::findByPasswordReset($_POST['token']);
	
		foreach ($_POST as $key => $value)
		{
			    $user->$key = $value;
		};
	
		if ($user->savePassword() === true)
		{
			View::render('Password/success.php');
		} else {
			View::render('Password/reset.php', [
				'token' => $token,
				'errors' => $user->errors
			]);
		}
	}
}
?>
