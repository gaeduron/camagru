<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Camagru.42</title>
<?php//<link rel="stylesheet" type="text/css" href="/App/Views/Layout/Layout.css">?>
	</head>
	<body>
		<?php require ('./App/Views/Layout/Header.php'); ?>
		<div class='body_wrapper'>
			<?php require ($file); ?>
		</div>
	</body>
</html>
