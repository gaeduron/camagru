<?php
use Core\Auth;

if (!Auth::isLoggedIn() && $file != "./App/Views/Auth/Login.php")
{
	echo '<nav>
			<ul>
				<li><h1>Camagru</h1></li>
				<form action="/login/create" method="post">
					<li><input class="side" type="text" name="mail" placeholder="e-mail" value="'.$mail.'"></li>
					<li><input class="side" type="password" name="password" placeholder="password"></li>
					<li><button class="side" type="submit" value="submit">sign-in</button></li>
				</form>
			</ul>
		</nav>';
}

if (!Auth::isLoggedIn() && $file == "./App/Views/Auth/Login.php")
{
	echo '<nav>
			<ul>
				<li><h1>Camagru</h1></li>
				<li><a href="/signup/new">Register</a></li>
			</ul>
		</nav>';
}

if (Auth::isLoggedIn()) //is authenticated
{
	echo
		'<nav>
			<ul>
				<li><a href="/">Home</a></li>
				<li><a href="#">Camagru</a></li>
				<li class="side"><a href="/login/destroy">Logout</a></li>
			</ul>
		</nav>';
}
if (0) //is admin
{
	
}
if (isset($_SESSION['message']))
{
	echo '<script>alert("'.$_SESSION['message'].'");</script>';
}
?>
