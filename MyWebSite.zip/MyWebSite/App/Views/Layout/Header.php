<nav>
      <ul>
        <li><a href="/">Home</a></li>
        <li><a href="#">Camagru</a></li>
        <li class="side"><a href="#">Connexion</a></li>
      </ul>
</nav>
