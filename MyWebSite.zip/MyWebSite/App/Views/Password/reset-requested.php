<div style="text-align:center;">
<h1>Forgot Password<h1></br>
<p>Please check your mail</p>
</div>
