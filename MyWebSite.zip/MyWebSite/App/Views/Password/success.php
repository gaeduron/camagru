<h1>Password reset</h1></br>
<p>Password reset successful !</br> You can now login with your new password</p>
