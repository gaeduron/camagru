<div style="text-align:center;">
<h1>Reset Password<h1>
<form action="/password/request-reset" method="post">
	<label for="mail">E-mail</label>
	<input type="text" name="mail" placeholder="e-mail" value="<?PHP echo $mail ?>"><br>
	
	<button type="submit" value="submit">reset password</button>
</form>
<?php
	if (!empty($errors))
	{
		foreach ($errors as $error)
		{
			echo '
				<div class="alert success">
					<span class="closebtn">&times;</span>
					<p>'.$error.'<p>
				</div>
			';
		}
	}
?>
	<script>
		var close = document.getElementsByClassName("closebtn");
		var i;

		for (i = 0; i < close.length; i++) {
			close[i].onclick = function(){
				var div = this.parentElement;
				div.style.opacity = "0";
				setTimeout(function(){ div.style.display = "none"; }, 500);
			}
		}
	</script>
</div>
