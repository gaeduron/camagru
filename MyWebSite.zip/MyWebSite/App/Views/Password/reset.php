<div style="text-align:center;">
<h1>Register new password<h1>
<form action="/password/change" method="post">

	
	<input type="hidden" name="token" value="<?php echo $token ?>">
	<label for="password">New password</label>
	<input type="password" name="password" placeholder="new password"><br>
	
	<label for="password_re">Confirm new password</label>
	<input type="password" name="password_re" placeholder="re-type new password"><br>
	
	<button type="submit" value="submit">save password</button>
</form>
<?php
	if (!empty($errors))
	{
		foreach ($errors as $error)
		{
			echo '
				<div class="alert success">
					<span class="closebtn">&times;</span>
					<p>'.$error.'<p>
				</div>
			';
		}
	}
?>
	<script>
		var close = document.getElementsByClassName("closebtn");
		var i;

		for (i = 0; i < close.length; i++) {
			close[i].onclick = function(){
				var div = this.parentElement;
				div.style.opacity = "0";
				setTimeout(function(){ div.style.display = "none"; }, 500);
			}
		}
	</script>
</div>
