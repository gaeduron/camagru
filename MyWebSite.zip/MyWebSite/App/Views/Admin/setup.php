<style>
input, select {
	width: 248px;
	color: #333;
	font-size: 0.8em;
    padding: 5px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

button {
    background-color: #08B2E3;
    border: none;
	color: white;
	margin-top: 20px;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
	font-size: 16px;
	border-radius: 2px;
}

button:hover {
	background-color: #EE6352;
}
</style>

<div style="text-align:center;">
<h1>Setup DB<h1>
<form action="/admin/setup/start" method="post">
    User: <input type="text" name="user" value="user"><br>
    Pass: <input type="password" name="password" value="password"><br>
    <button type="submit" value="START OR RESTART">START OR RESTART</button>
</form>
<p>Please start the Database to use the site</p>
</div>
