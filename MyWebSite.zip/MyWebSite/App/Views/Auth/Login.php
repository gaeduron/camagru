<div style="text-align:center;">
<h1>Login<h1>
<form action="/login/create" method="post">
	<label for="mail">E-mail</label>
	<input type="text" name="mail" placeholder="e-mail" value="<?PHP echo $mail ?>"><br>

	<label for="password">Password</label>
	<input type="password" name="password" placeholder="password"><br>
	
	<button type="submit" value="submit">submit</button>
</form>
<a href="/password/forgot">Forgot account?</a>
<?php
	if (!empty($errors))
	{
		foreach ($errors as $error)
		{
			echo '
				<div class="alert success">
					<span class="closebtn">&times;</span>
					<p>'.$error.'<p>
				</div>
			';
		}
	}
?>
	<script>
		var close = document.getElementsByClassName("closebtn");
		var i;

		for (i = 0; i < close.length; i++) {
			close[i].onclick = function(){
				var div = this.parentElement;
				div.style.opacity = "0";
				setTimeout(function(){ div.style.display = "none"; }, 500);
			}
		}
	</script>
</div>
