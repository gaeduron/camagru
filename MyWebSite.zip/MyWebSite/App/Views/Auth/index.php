<style>
input, select {
    width: 248px;
    color: #333;
    font-size: 0.8em;
    padding: 5px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

button {
    background-color: #08B2E3;
    border: none;
    color: white;
    margin-top: 20px;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    border-radius: 2px;
}

button:hover {
    background-color: #EE6352;
}
</style>

<div style="text-align:center;">
<h1>Sign-up<h1>
<form action="/signup/create" method="post">
	<label for="user">Name</label>
	<input type="text" name="name" placeholder="name"><br>
	
	<label for="mail">E-mail</label>
	<input type="text" name="mail" placeholder="e-mail"><br>

	<label for="password">Password</label>
	<input type="password" name="password" placeholder="password"><br>
	
	<label for="password_re">Repeat Password</label>
	<input type="password" name="password_re" placeholder="password"><br>
    <button type="submit" value="submit">submit</button>
</form>
<?php
	if (!empty($errors))
	{
		foreach ($errors as $error)
		{
			echo '
				<div class="alert success">
					<span class="closebtn">&times;</span>
					<p>'.$error.'<p>
				</div>
			';
		}
	}
?>
	<script>
		var close = document.getElementsByClassName("closebtn");
		var i;

		for (i = 0; i < close.length; i++) {
			close[i].onclick = function(){
				var div = this.parentElement;
				div.style.opacity = "0";
				setTimeout(function(){ div.style.display = "none"; }, 500);
			}
		}
	</script>
</div>
