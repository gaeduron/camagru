<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <title>HOME</title>
</head>
<body>
	<h1>Home page</h1>
	<p class="text">Welcome <?php echo htmlspecialchars($user->mail) ?> to the index page of home controller</p>
</body>
</html>
