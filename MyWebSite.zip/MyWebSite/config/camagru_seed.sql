SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{"db":"camagru","table":"users"},{"db":"camagru","table":"posts"}]');

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'camagru', 'users', '[]', '2017-07-12 17:08:22');

INSERT INTO `posts` (`id`, `title`, `content`, `created_at`) VALUES
(1, 'title 1', 'epfpoaerj  aporijg g j asjgaoijasgj[ ', '2017-07-12'),
(2, 'title 2', 'jaoiu niuy fosodu oasjuv jrgvupz joy', '2017-07-12');

INSERT INTO `users` (`id`, `name`, `mail`, `password_hash`, `password_reset_hash`, `password_reset_expires_at`, `activation_hash`, `is_active`) VALUES
(1, 'Paul_le_bg', 'paul@2gropec.com', 'qwerty', NULL, NULL, NULL, 0),
(3, 'pol', 'pierre', 'jack', NULL, NULL, NULL, 0),
(4, 'name', 'mail', 'password_hash', NULL, NULL, NULL, 0),
(5, 'pol', 'pol@2gropec.com', '$2y$10$axo5zgdLs5FYsbWLm6xp4.DinSI/K1xmH5PFehI9kcIhlOkL9sTUy', NULL, NULL, NULL, 0),
(6, 'test', 'test@2gropec.com', '$2y$10$Hl1r8GAvaXAyMujlK3M0YOnvWYrBq2eyCNGYPCQIlmXomQo00Y9LO', NULL, NULL, NULL, 0),
(7, 'test', 'test@test.com', '$2y$10$GKKA7wUx0YvhQsNfi8kbHeQiHepKq5diNXJ8/Q2KvkutHmiMnoOk.', '1e86f56b5919aa8c7858bd116060ee6f589cd173ebdd84161d29ad86f85276d7', '2017-07-18 14:10:19', NULL, 0),
(15, 'gqetqn', 'gaetan.duron@gmail.com', '$2y$10$eDm2zX3XCxyoOX9i1zyuy.eaSbgYKQthgK9I5Ow3R2Wzfgno7OUby', '574074955b1c03987a36c2fb683f32daac361b78f3031a71421e31be12299924', '2017-07-18 20:26:56', 'a9361dcafc117c83bf25dd2f63eacd43ef026f85c8f5a2ba80bdfdf86ed36798', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
