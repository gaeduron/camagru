SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{"db":"camagru","table":"users"},{"db":"camagru","table":"posts"}]');

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'camagru', 'users', '[]', '2017-07-12 17:08:22');

INSERT INTO `users` (`id`, `name`, `mail`, `password_hash`) VALUES
(1, 'Paul_le_bg', 'paul@2gropec.com', 'qwerty'),
(3, 'pol', 'pierre', 'jack'),
(4, 'name', 'mail', 'password_hash'),
(5, 'pol', 'pol@2gropec.com', '$2y$10$axo5zgdLs5FYsbWLm6xp4.DinSI/K1xmH5PFehI9kcIhlOkL9sTUy'),
(6, 'test', 'test@2gropec.com', '$2y$10$Hl1r8GAvaXAyMujlK3M0YOnvWYrBq2eyCNGYPCQIlmXomQo00Y9LO');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
