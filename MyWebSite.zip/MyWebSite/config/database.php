<?php
$DB_DSN = "mysql:host=localhost;dbname=camagru;charset=utf8";
$DB_USER = "root";
$DB_PASSWORD = "root";
?>
