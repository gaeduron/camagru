<?php
require ("database.php");

$DB_DSN = "mysql:host=localhost;charset=utf8";
$pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
$pdo->query("CREATE DATABASE camagru;");

require ("database.php");
$db = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
$db->query(file_get_contents("camagru_schema.sql"));
?>
