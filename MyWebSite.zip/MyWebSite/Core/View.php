<?php
namespace Core;

class View
{
	public function render($view, $args = [])
	{
		$file = "./App/Views/".$view;
		extract ($args, EXTR_SKIP);

		if (is_readable($file))
			require ("./App/Views/Layout/Layout.php");
		else
			echo "$file not found";
	}
}
?>
