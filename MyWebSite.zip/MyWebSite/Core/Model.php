<?php
namespace Core;

use PDO;
//require ("./config/seed.php");

class Model
{
	public static function getDb()
	{
		require ("./config/database.php");
		$pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
		return ($pdo);
	}

	private function createDb()
	{
		require ("./config/database.php");
		$DB_DSN = "mysql:host=localhost;charset=utf8";
		$pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
		$pdo->query("CREATE DATABASE camagru;");
	}

	public function setupDb()
	{
		Model::createDb();
		$db = Model::getDb();
		$db->query(file_get_contents("./config/camagru_schema.sql"));
		$db->query(file_get_contents("./config/camagru_seed.sql"));
	}

	public function checkDb()
	{
		require ("./config/database.php");
		$DB_DSN = "mysql:host=localhost;charset=utf8";
		$pdo = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
		$databases = $pdo->query('SHOW databases')->fetchAll(PDO::FETCH_COLUMN, 0);
		if (!in_array("camagru", $databases))
			return (0);
		return (1);
	}
}
?>
