<?php
namespace Core;

use App\Controllers\Signup;
use Core\Auth;

class Controller
{
	protected $route_params = [];

	public function __construct ($route_params)
	{
		$this->route_params = $route_params;
	}
	
	public function __call ($name, $args)
	{
		$method = $name."Action";
		if (method_exists($this, $method))
		{
			if ($this->before() === true)
				call_user_func_array([$this, $method], $args);
			$this->after();
		}
		else
			echo "Method: ".$method." not found in controller: ".get_class($this);
	}

	public function before()
	{
		$class_name = get_class($this);
		if (($class_name != 'App\Controllers\Signup'
			&& $class_name != 'App\Controllers\Login'
			&& $class_name != 'App\Controllers\Password')
			&& !Auth::isLoggedIn())
		{
			Auth::rememberRequestedPage();
			$_SESSION['message'] = "Please Login to access the site";
			$signup = new Signup("signup/new");	
			$signup->newAction();
			return false;
		}
		return true;
	}
	
	public function after()
	{
		unset($_SESSION['message']);
	}

	public function redirect($url)
	{
		header("Location: http://".$_SERVER['HTTP_HOST'].$url, true, 303);
	}
}
?>
